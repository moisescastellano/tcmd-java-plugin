 
 Hi!

 Here's a model of Pink Panther I made for my future 3D-Stereogram.
 The model is absolutely free for you, use it in any project you want.
 Though creds aren't necessary but appreciated.

 There's no texture, proper polygons have needed material. 
 Ambient color is recommended to make it look like a cartoon.

 Any feedback is appreciated - 3Dimka(at)gmail(.)com
 And if you add bones and physique I would love to have a copy from you ;)

 3Dimka
